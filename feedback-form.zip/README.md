# feedback-form
Description: Create a feedback.html file with a form that includes: Name field Email field Rating field (1 to 5) Text box for comments Use SCSS to style the form responsively. In the feedback.js file, add a submission event that validates the required fields and displays a thank-you message.
